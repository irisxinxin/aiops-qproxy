#!/bin/bash
# 打包脚本 - 将所有修改后的文件打包

set -e

echo "📦 打包 aiops-qproxy 项目..."

# 创建临时目录
TEMP_DIR=$(mktemp -d)
echo "临时目录: $TEMP_DIR"

# 复制项目文件
echo "📋 复制项目文件..."
cp -r ../aiops-qproxy "$TEMP_DIR/"

# 进入临时目录
cd "$TEMP_DIR"

# 清理不需要的文件
echo "🧹 清理不需要的文件..."
cd aiops-qproxy
rm -rf .git
rm -rf conversations/
rm -rf logs/
rm -f *.log
rm -f *.pid

# 创建打包文件
echo "📦 创建打包文件..."
cd ..
tar -czf aiops-qproxy-fixed.tar.gz aiops-qproxy/

# 移动到原目录
mv aiops-qproxy-fixed.tar.gz /Users/xin/Desktop/aiops-qproxy/

echo "✅ 打包完成！"
echo "📁 打包文件: /Users/xin/Desktop/aiops-qproxy/aiops-qproxy-fixed.tar.gz"
echo ""
echo "📋 包含的脚本："
echo "  - scripts/deploy-real-q.sh (部署脚本)"
echo "  - scripts/test-real-q.sh (测试脚本)"
echo "  - scripts/diagnose-real-q.sh (诊断脚本)"
echo "  - scripts/fix-real-q.sh (修复脚本)"
echo ""
echo "🚀 上传到远程服务器："
echo "  scp aiops-qproxy-fixed.tar.gz ubuntu@your-server-ip:~/"
echo ""
echo "🔧 在远程服务器解压："
echo "  tar -xzf aiops-qproxy-fixed.tar.gz"
echo "  cd aiops-qproxy"
echo "  chmod +x scripts/*.sh"
echo "  ./scripts/fix-real-q.sh"
